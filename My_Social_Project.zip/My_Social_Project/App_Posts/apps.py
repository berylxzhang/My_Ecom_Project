from django.apps import AppConfig


class AppPostsConfig(AppConfig):
    name = 'App_Posts'
