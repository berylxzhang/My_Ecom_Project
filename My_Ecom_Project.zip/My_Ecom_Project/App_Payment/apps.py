from django.apps import AppConfig


class AppPaymentConfig(AppConfig):
    name = 'App_Payment'
