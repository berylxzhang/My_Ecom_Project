from django.apps import AppConfig


class AppLoginConfig(AppConfig):
    name = 'App_Login'
